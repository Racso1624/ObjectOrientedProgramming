/*

App.js

Autores:
Pedro Arriola 20188 패드로 아리어라
Oscar López 20679 어스칼 로팻스
Marco Orozco 마르코 오롯스코
Santiago Taracena 20017 산띠아고 탈으세나
Yong Park 20117 박용범

Última modificación: 2020-10-07

*/

// Librerías utilizadas.
import React, {Component} from "react"

// Componentes utilizados.
import ProjectRouter from "./pages/ProjectRouter"

// Clase App que contiene al Router de la página.
class App extends Component {

  // Método que renderiza la página.
  render() {
    return (
      <div>
        <ProjectRouter/>
      </div>
    )
  }
}

export default App