/*

AboutUs.js

Autores:
Pedro Arriola 20188 패드로 아리어라
Oscar López 20679 어스칼 로팻스
Marco Orozco 마르코 오롯스코
Santiago Taracena 20017 산띠아고 탈으세나
Yong Park 20117 박용범

Última modificación: 2020-10-07

*/

// Librería utilizada.
import React from "react"

// Componentes utilizados.
import NavigationBar from "./components/NavigationBar"
import Texto from "./components/DescriptionAboutUs"
import MainAboutUs from "./components/MainAboutUs"
import DeveloperCard from "./components/DeveloperCard"

// Imágenes utilizadas.
import Pedro from "./components/images/team/el_tio.jpg"
import Marco from "./components/images/team/marco.png"
import Santiago from "./components/images/team/santiago.jpg"
import Oscar from "./components/images/team/oscar.jpg"
import Yong from "./components/images/team/yong.jpg"

// Estilos utilizados.
import "./components/styles/coursestyle.css"

// Método que retorna la página AboutUs.
const AboutUs = () => {
    return (
        <div>
            <NavigationBar/>
            <MainAboutUs/>
            <Texto/>
            <div className = "row padding-top content-centeredbox">
                <div className = "col-md-2 developer-box">
                    <DeveloperCard
                        image = {Pedro}
                        description = '"El Universo está gobernado por las matemáticas y eso me apasiona mucho. Saber matemáticas es una herramienta útil que nunca olvidarás."'
                    />
                    <p className = "right-text"><b>- Pedro Arriola</b></p>
                </div>
                <div className = "col-md-2 developer-box">
                    <DeveloperCard
                        image = {Marco}
                        description = '"Las matemáticas tienen aplicaciones en todos lados: informática, arquitectura, economía, etc. Todos merecemos tener buenas bases matemáticas."'
                    />
                    <p className = "right-text"><b>- Marco Orozco</b></p>
                </div>
                <div className = "col-md-2 developer-box">
                    <DeveloperCard
                        image = {Santiago}
                        description = '"Si observamos el mundo que nos rodea, podemos ver que las matemáticas se hallan en todos lados. Eso siempre me ha parecido increíble e impresionante."'
                    />
                    <p className = "right-text"><b>- Santiago Taracena</b></p>
                </div>
                <div className = "col-md-2 developer-box">
                    <DeveloperCard
                        image = {Oscar}
                        description = '"Cuando se profundiza en el estudio de las matemáticas, se puede descubrir la belleza y la hermosa realidad que detrás de ellas se esconde..."'
                    />
                    <p className = "right-text"><b>- Oscar López</b></p>
                </div>
                <div className = "col-md-2 developer-box">
                    <DeveloperCard
                        image = {Yong}
                        description = '"Las matemáticas siempre me han parecido divertidas e impresionantes. Nuestra plataforma busca que todo el mundo pueda amar las matemáticas."'
                    />
                    <p className = "right-text"><b>- Yong Park</b></p>
                </div>
            </div>
        </div>
    )
}

export default AboutUs