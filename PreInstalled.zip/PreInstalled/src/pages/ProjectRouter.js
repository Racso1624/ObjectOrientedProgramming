/*

ProjectRouter.js

Autores:
Pedro Arriola 20188 패드로 아리어라
Oscar López 20679 어스칼 로팻스
Marco Orozco 마르코 오롯스코
Santiago Taracena 20017 산띠아고 탈으세나
Yong Park 20117 박용범

Última modificación: 2020-10-07

*/

// Librerías utilizadas.
import React from "react"
import {BrowserRouter as Router, Route, Switch, Redirect} from "react-router-dom"

// Componentes utilizados.
import LandingPage from "./LandingPage"
import Courses from "./Courses"
import Login from "./Login"
import AboutUs from "./AboutUs"

// Componentes de los cursos realizados.
import ArithmeticCourse from "./ArithmeticCourse"
import AlgebraCourse from "./AlgebraCourse"
import GeometryCourse from "./GeometryCourse"
import ArithmeticExam from "./ArithmeticExam"
import AlgebraExam from "./AlgebraExam"
import GeometryExam from "./GeometryExam"

// Método que retorna el Router de la página.
const ProjectRouter = () => {
    return (
        <Router>
            <Redirect from = "/" to = "/inicio"/>
            <Switch>
                <Route exact path = "/inicio" component = {LandingPage}/>
                <Route exact path = "/cursos" component = {Courses}/>
                <Route exact path = "/login" component = {Login}/>
                <Route exact path = "/nosotros" component = {AboutUs}/>

                <Route exact path = "/arithmetic" component = {ArithmeticCourse}/>
                <Route exact path = "/algebra" component = {AlgebraCourse}/>
                <Route exact path = "/geometry" component = {GeometryCourse}/>

                <Route exact path = "/arithmeticexam" component = {ArithmeticExam}/>
                <Route exact path = "/algebraexam" component = {AlgebraExam}/>
                <Route exact path = "/geometryexam" component = {GeometryExam}/>
            </Switch>
        </Router>
    )
}

export default ProjectRouter