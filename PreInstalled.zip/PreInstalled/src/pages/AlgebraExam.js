import React from "react"
import {Link} from "react-router-dom"

import NavigationBar from "./components/NavigationBar"
import Algebra from "./components/Algebra"

import Arrow from "./components/images/courseimages/flechita.png"

const AlgebraExam = () => {

    const style = {
        width: "50px",
        padding: "10px",
    }

    return (
        <div>
            <NavigationBar/>
            <Link href = "#" to = "/cursos"><img style = {style} src = {Arrow}/></Link>
            <Algebra/>
        </div>      
    )
}

export default AlgebraExam