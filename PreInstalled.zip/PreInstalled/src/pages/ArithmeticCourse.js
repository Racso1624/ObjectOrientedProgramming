import React from "react"
import ReactPlayer from "react-player"
import {Link} from "react-router-dom"

import "./components/styles/coursestyle.css"

import NavigationBar from "./components/NavigationBar"
import Arrow from "./components/images/courseimages/flechita.png"

const ArithmeticCourse = () => {

    const style = {
        width: "50px",
        padding: "10px",
    }

    return (
        <div>
            <NavigationBar/>
            <Link href = "#" to = "/cursos"><img style = {style} src = {Arrow}/></Link>
            <h2 className = "content-centeredbox top-margin-extreme">Clase #1: Jerarquía de operaciones.</h2>
            <div className = "content-centeredbox top-margin">
                <ReactPlayer
                    url = "https://youtu.be/vSTEWso5mrM"
                    controls = {true}
                />
            </div>
        </div>
    )
}

export default ArithmeticCourse