/*

Courses.js

Autores:
Pedro Arriola 20188 패드로 아리어라
Oscar López 20679 어스칼 로팻스
Marco Orozco 마르코 오롯스코
Santiago Taracena 20017 산띠아고 탈으세나
Yong Park 20117 박용범

Última modificación: 2020-10-07

*/

// Librerías utilizadas.
import React from "react"

// Componentes utilizados.
import NavigationBar from "./components/NavigationBar"
import CoursesBanner from "./components/CoursesBanner"
import CourseCard from "./components/CourseCard"

// Imágenes utilizadas.
import AritmeticImage from "./components/images/courseimages/aritmetic.jpg"
import AlgebraImage from "./components/images/courseimages/algebra.jpg"
import GeometryImage from "./components/images/courseimages/geometria.jpg"

// Estilos utilizados.
import "./components/styles/coursestyle.css"

// Método que retorna la página Courses.
const Courses = () => {
    return (
        <div>
            <NavigationBar/>
            <CoursesBanner/>
            <div className = "row padding-top content-centeredbox">
                <div className = "col-md-3 content-box">
                    <CourseCard
                        image = {AritmeticImage}
                        title = "Aritmética"
                        description = "Aprende a realizar operaciones aritméticas mediante jerarquías y otras herramientas."
                        courseroute = "/arithmetic"
                        examroute = "/arithmeticexam"
                    />
                </div>
                <div className = "col-md-3 content-box">
                    <CourseCard
                        image = {AlgebraImage}
                        title = "Álgebra"
                        description = "Descubre las bases del álgebra, ecuaciones, factorización, entre otros fascinantes temas."
                        courseroute = "/algebra"
                        examroute = "/algebraexam"
                    />
                </div>
                <div className = "col-md-3 content-box">
                    <CourseCard
                        image = {GeometryImage}
                        title = "Geometría"
                        description = "Descripción random para hacer una prueba con la interfaz gráfica de la plataforma web."
                        courseroute = "/geometry"
                        examroute = "/geometryexam"
                    />
                </div>
            </div>
        </div>
    )
}

export default Courses