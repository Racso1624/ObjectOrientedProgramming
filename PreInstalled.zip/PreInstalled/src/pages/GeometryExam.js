import React from "react"
import {Link} from "react-router-dom"

import NavigationBar from "./components/NavigationBar"
import Geometry from "./components/Geometry"

import Arrow from "./components/images/courseimages/flechita.png"

const GeometryExam = () => {

    const style = {
        width: "50px",
        padding: "10px",
    }

    return (
        <div>
            <NavigationBar/>
            <Link href = "#" to = "/cursos"><img style = {style} src = {Arrow}/></Link>
            <Geometry/>
        </div>      
    )
}

export default GeometryExam