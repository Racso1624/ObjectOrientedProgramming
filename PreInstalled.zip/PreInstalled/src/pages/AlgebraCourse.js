import React from "react"
import ReactPlayer from "react-player"
import {Link} from "react-router-dom"

import NavigationBar from "./components/NavigationBar"

import Arrow from "./components/images/courseimages/flechita.png"

const AlgebraCourse = () => {

    const style = {
        width: "50px",
        padding: "10px",
    }

    return (
        <div>
            <NavigationBar/>
            <Link href = "#" to = "/cursos"><img style = {style} src = {Arrow}/></Link>
            <h2 className = "content-centeredbox top-margin-extreme">Nuestro contenido se encontrará disponible próximamente...</h2>
            <div className = "content-centeredbox top-margin">
                <ReactPlayer
                    url = "https://youtu.be/0MWr4dB1zyw"
                    controls = {true}
                />
            </div>
        </div>
    )
}

export default AlgebraCourse