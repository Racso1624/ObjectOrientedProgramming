/*

NavigationBar.jsx

Autores:
Pedro Arriola 20188 패드로 아리어라
Oscar López 20679 어스칼 로팻스
Marco Orozco 마르코 오롯스코
Santiago Taracena 20017 산띠아고 탈으세나
Yong Park 20117 박용범

Última modificación: 2020-10-07

*/

// Librerías utilizadas.
import React, {Component} from "react"
import {Link} from "react-router-dom"

// Imágenes utilizadas.
import Logo from "./images/logo.png"

// Estilos utilizados.
import "./styles/navbarstyle.css"

// <nav className="navbar navbar-expand-lg navbar-light bg-light">

// <div className="collapse navbar-collapse" id="navbarNav">

// <ul className = "navbar-nav ml-auto">

// Clase NavigationBar que retorna el componente NavigationBar.
class NavigationBar extends Component {
    render() {
        return (
            <section id = "nav-bar">
                <div className = "navbar">
                    <nav className = "navbar navbar-expand-lg">
                        <Link className = "navbar-brand" href = "#" to = "/inicio"><img src = {Logo}/></Link>
                        <div>
                            <section id = "links">
                            <ul className = "navbar-nav">
                                <li className="nav-item">
                                    <Link className = "nav-link" href = "#" to = "/cursos">CURSOS</Link>
                                </li>
                                <li className="nav-item">
                                    <Link className = "nav-link" href = "#" to = "/nosotros">QUIENES SOMOS</Link>
                                </li>
                            </ul>
                            </section>
                        </div>
                    </nav>
                </div>
            </section>
        )
    }
}

/*
<li className="nav-item">
    <Link className = "nav-link" href = "#" to = "/login">INICIAR SESION</Link>
</li>
*/

export default NavigationBar