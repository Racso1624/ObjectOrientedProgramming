import React, {Component} from "react"

import "./styles/coursestyle.css"

class DeveloperCard extends Component {
    render() {
        return (
            <div className = "container">
                <div className = "row justify-content-center">
                    <div className = "col-md-12 developer-box">
                        <div>
                            <img src = {this.props.image} className = "card-img-dev" alt = "..."/>
                        </div>
                        <div className = "centered-content">
                            <div className = "content-centeredbox">
                                <p>{this.props.description}</p>
                            </div>                    
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default DeveloperCard