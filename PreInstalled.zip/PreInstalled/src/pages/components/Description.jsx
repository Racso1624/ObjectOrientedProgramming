/*

Description.jsx

Autores:
Pedro Arriola 20188 패드로 아리어라
Oscar López 20679 어스칼 로팻스
Marco Orozco 마르코 오롯스코
Santiago Taracena 20017 산띠아고 탈으세나
Yong Park 20117 박용범

Última modificación: 2020-10-07

*/

// Librerías utilizadas.
import React, {Component} from "react"

// Imágenes utilizadas.
import FirstDesc from "./images/landingpageimages/desc1.png"
import SecondDesc from "./images/landingpageimages/desc2.png"
import ThirdDesc from "./images/landingpageimages/desc3.png"

// Estilos utilizados.
import "./styles/style.css"

// Clase Description que retorna el componente Description.
class Description extends Component {
    render() {
        return (
            <section id="desc">
                <div className="container">
                <h2 className="titulo-desc">¿CÓMO FUNCIONA?</h2>
                    <div className="row text-center">
                        <div class="col-md-4 desc">
                            <img src={FirstDesc} class="desc-img"></img>
                            <h4>Escoge un curso</h4>
                            <h5>Escoge un curso que necesites reforzar o te llame la atención en nuestra sección de cursos.</h5>
                        </div>
                        <div className="col-md-4 desc">
                            <img src={SecondDesc} class="desc-img"></img>
                            <h4>Resuelve las lecciones</h4>
                            <h5>Pon atención y trata de comprender los procedimientos realizados en nuestros cursos.</h5>
                        </div>
                        <div className="col-md-4 desc">
                            <img src={ThirdDesc} class="desc-img"></img>
                            <h4>Aprueba el examen</h4>
                            <h5>Al final de cada sección hay un examen para comprobar tu desempeño ¡Ánimo! Mejorar depende de ti.</h5>
                        </div>
                    </div>
                </div>
            </section>
        )
    }
}

export default Description