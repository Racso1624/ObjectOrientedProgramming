/*

CoursesBanner.jsx

Autores:
Pedro Arriola 20188 패드로 아리어라
Oscar López 20679 어스칼 로팻스
Marco Orozco 마르코 오롯스코
Santiago Taracena 20017 산띠아고 탈으세나
Yong Park 20117 박용범

Última modificación: 2020-10-07

*/

// Librerías utilizadas.
import React, {Component} from "react"
import Test from "./images/courseimages/papelesgeometria.png"

// Imágenes utilizadas.
import Waves from "./images/waves.png"

// Estilos utilizados.
import "./styles/bannerstyle.css"

// Clase CoursesBanner que retorna el componente CoursesBanner.
class CoursesBanner extends Component {
    render() {
        return (
            <section id = "banner">
                <div className="container">
                    <div className="row justify-content-center">
                        <div class="col-md-6">
                            <p className = "titulo-atractivo">¿QUÉ CURSOS OFRECEMOS?</p>
                            <h5>
                                Actualmente contamos con tres cursos con un nivel de dificultad 
                                accesible para que puedas repasar: Aritmética, Álgebra y Geometría.
                                Elige uno de los cursos que nuestra plataforma ofrece y resuélvelo 
                                a tu ritmo. 
                            </h5>
                            <h5>
                                Nuestros cursos se basan en nuestros propios aprendizajes, junto con 
                                la implementación de técnicas de estudio y enseñanza digitales que harán 
                                que cada vídeo se sienta como una experiencia nueva y sencilla de seguir. 
                            </h5>
                            <h5>
                                Esperamos que puedas mejorar gracias a nuestros cursos, y sobre todo, que ellos  
                                consigan que ames las matemáticas tanto como nosotros.
                            </h5>
                        </div>
                        <div className = "col-md-6 text center">
                            <img src = {Test} className = "img-banner"></img>
                        </div>
                    </div>
                </div>
                <img src = {Waves} className = "efectobanner"/>
            </section>
        )
    }
}

export default CoursesBanner

