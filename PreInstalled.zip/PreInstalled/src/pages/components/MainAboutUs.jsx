/*

MainAboutUs.jsx

Autores:
Pedro Arriola 20188 패드로 아리어라
Oscar López 20679 어스칼 로팻스
Marco Orozco 마르코 오롯스코
Santiago Taracena 20017 산띠아고 탈으세나
Yong Park 20117 박용범

Última modificación: 2020-10-07

*/

// Librerías utilizadas.
import React, {Component} from "react"

// Imágenes utilizadas.
import Waves from "./images/waves.png"
import UVG from "./images/whoareweimages/quienes.png"

// Estilos utilizados.
import "./styles/bannerstyle.css"

// Clase MainAboutUs que retorna el componente MainAboutUs.
class MainAboutUs extends Component {
    render() {
        return (
            <section id = "banner">
                <div className = "container">
                    <div className = "row justify-content-center">
                        <div className = "col-md-6">
                            <p className = "titulo-atractivo">¿QUIENES SOMOS?</p>
                            <h5>
                                En muchas ocasiones, los usuarios de una plataforma o aplicación llegan 
                                a ser expertos en el manejo de la misma. Sin embargo, conocer el trasfondo 
                                de una pieza de software es algo muy importante, ya que nos puede decir 
                                el por qué de la existencia de esa misma pieza.
                            </h5>
                            <h5>
                                Nosotros, los desarrolladores de A-Plus, somos estudiantes apasionados 
                                por las matemáticas, cuyo objetivo es compartir conocimientos y hacer que 
                                todo el mundo pueda llegar a disfrutar y sentir tanto cariño por las matemáticas 
                                como nosotros sentimos. Esperamos que disfrutes de nuestras historias.
                            </h5>
                        </div>
                        <div className = "col-md-6 text center">
                            <img src = {UVG} className = "img-banner"></img>
                        </div>
                    </div>
                </div>
                <img src = {Waves} className = "efectobanner"/>
            </section>
        )
    }
}

export default MainAboutUs