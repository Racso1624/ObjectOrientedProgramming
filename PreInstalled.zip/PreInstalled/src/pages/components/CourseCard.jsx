/*

CourseCard.jsx

Autores:
Pedro Arriola 20188 패드로 아리어라
Oscar López 20679 어스칼 로팻스
Marco Orozco 마르코 오롯스코
Santiago Taracena 20017 산띠아고 탈으세나
Yong Park 20117 박용범

Última modificación: 2020-10-07

*/

// Librerías utilizadas.
import React, {Component} from "react"
import {Link} from "react-router-dom"

// Estilos utilizados.
import "./styles/coursestyle.css"

// Clase CourseCard que retorna el componente CourseCard.

// <div className = "card-body">

class CourseCard extends Component {
    render() {
        return (
            <div className = "container">
                <div className = "row justify-content-center padding-top">
                    <div className = "col-md-10 content-box">
                        <div>
                            <img src = {this.props.image} className = "card-img-top" alt = "..."/>
                        </div>
                        <div className = "centered-content">
                            <div className = "content-centeredbox">
                                <h5>{this.props.title}</h5>
                            </div>
                            <div className = "content-centeredbox">
                                <p>{this.props.description}</p>
                            </div>
                            <div>
                                <Link className = "btn btn-primary content-centeredbox" href = "#" to = {this.props.courseroute}>Ver curso</Link>
                            </div> 
                            <div>
                                <Link className = "btn btn-primary content-centeredbox top-margin" href = "#" to = {this.props.examroute}>Realizar examen</Link>
                            </div>                           
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

// <a href = "#" className = "btn btn-primary">

export default CourseCard