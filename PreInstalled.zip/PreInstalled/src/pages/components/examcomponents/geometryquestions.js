const qBank = [
  {
    question: "¿Cuál es el área de un cuadrado con lados de 5 centímetros?",
    answers: ["20 cm²", "25 cm²", "12.5 cm²", "15 cm²"],
    correct: "25 cm²",
    questionId: "099099"
  },
  {
    question: "¿Cuál es el área de un triángulo con base de 4 centímetros y altura de 6 centímetros?",
    answers: ["24 cm²", "20 cm²", "16 cm²", "12 cm²"],
    correct: "12 cm²",
    questionId: "183452"
  },
  {
    question: "¿Cuál es el volúmen de un cubo con aristas de 3 centímetros?",
    answers: ["9 cm³", "27 cm³", "81 cm³", "30 cm³"],
    correct: "27 cm³",
    questionId: "267908"
  },
  {
    question: "¿Cuál es el perímetro de un círculo con un radio de 4 centímetros?",
    answers: ["8π cm", "4π cm", "16π cm", "12π cm"],
    correct: "8π cm",
    questionId: "333247"
  },
  {
    question: "¿Cuál es el área de un círculo con un radio de 6 centímetros?",
    answers: ["12π cm²", "36π cm²", "18π cm²", "32π cm²"],
    correct: "36π cm²",
    questionId: "496293"
  },
  {
    question: "¿Cuál es el área de un rectángulo con una base de 7 centímetros y una altura de 5 centímetros?",
    answers: ["35 cm²", "30 cm²", "40 cm²", "70 cm²"],
    correct: "35 cm²",
    questionId: "588909"
  },
  {
    question: "¿Cuál es el área de un cilindro con un radio de 2 metros y una altura de 6 metros?",
    answers: ["12π m³", "36π m³", "20π m³", "24π m³"],
    correct: "24π m³",
    questionId: "648452"
  },
  {
    question: "¿Cuál es el perímetro de un triángulo escaleno con lados de 5, 7 y 20 centímetros?",
    answers: ["5 cm", "100 cm", "32 cm", "700 cm"],
    correct: "32 cm",
    questionId: "786649"
  },
  {
    question: "¿Cuál es el perímetro de un pentágono con lados de 8 centímetros?",
    answers: ["16 cm", "40 cm²", "8 cm", "40 cm"],
    correct: "40 cm",
    questionId: "839754"
  },
  {
    question: "¿Cuál es el área de un cuadrado con lados de 11 metros?",
    answers: ["22 m²", "121 cm²", "121 m", "121 m²"],
    correct: "121 m²",
    questionId: "98390"
  },
  {
    question: "¿Cuál es el área de un romboide con una base de 0.8 metros y una altura de 2 metros?",
    answers: ["1.6 m²", "16 m²", "8 m²", "16 cm²"],
    correct: "16 m²",
    questionId: "1071006"
  },
  {
    question: "¿Cuál es el perímetro de un rombo con lados de 8 centímetros?",
    answers: ["16 cm", "32 m", "64 cm", "32 cm"],
    correct: "32 cm",
    questionId: "1174154"
  },
  {
    question: "¿Cuál es el área de un trapecio con una base inferior de 5 metros, una base superior de 100 cm y una altura de 8 metros?",
    answers: ["24 cm²", "420 m²", "24 m²", "420 cm²"],
    correct: "24 m²",
    questionId: "1226535"
  },
  {
    question: "¿Cuál es el perímetro de un hexágono con un lados de 5 metros?",
    answers: ["30 m", "10 m", "25 m", "20 m"],
    correct: "30 m",
    questionId: "1310938"
  },
  {
    question: "¿Cuál es el perímetro de un triángulo isósceles con lados de 1 metro y una base de 50 centímetros?",
    answers: ["5 m", "205 cm", "250 cm", "2500 cm"],
    correct: "205 cm",
    questionId: "1436873"
  },
  {
    question: "¿Cuál es el perímetro de un triángulo equilátero con lados de 5 centímetros?",
    answers: ["20 cm", "10 cm", "15 cm", "5 cm"],
    correct: "15 cm",
    questionId: "1515110"
  },
  {
    question: "¿Cuál es el área un rectángulo con un lados de 5 y 8 metros?",
    answers: ["40 m²", "30 m²", "13 m²", "50 m²"],
    correct: "40 m²",
    questionId: "1642728"
  },
  {
    question: "¿Cuál es el perímetro de un rectángulo con lados de 5 y 6 centímetros?",
    answers: ["30 cm", "22 cm", "20 cm", "32 cm"],
    correct: "22 cm",
    questionId: "1747256"
  }
];

export default (n = 5) =>
  Promise.resolve(qBank.sort(() => 0.5 - Math.random()).slice(0, n));
