import React from "react"

const Result = ({score, playAgain}) => (
  <div className = "score-board">
    <div className = "score">¡Has respondido correctamente {score} / 5 respuestas!</div>
    <button className = "playBtn" onClick = {playAgain}>
      Inténtalo de nuevo.
    </button>
  </div>
)

export default Result