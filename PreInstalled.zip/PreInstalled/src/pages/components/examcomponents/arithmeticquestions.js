const qBank = [
  {
    question: "¿Cuál es el resultado de operar (6 x 4) + 10",
    answers: ["84", "34", "46", "64"],
    correct: "34",
    questionId: "099099"
  },
  {
    question: "¿Cuál es el resultado de operar (2 + 6) - ([2 x 2] + 1)",
    answers: ["5", "13", "6", "3"],
    correct: "3",
    questionId: "183452"
  },
  {
    question:"¿Cuál es el resultado de operar (8 / 4) x 6 + 5?",
    answers: ["17", "22", "44", "15"],
    correct: "17",
    questionId: "267908"
  },
  {
    question: "¿Cuál es el resultado de operar ([5 x 2] + [8 - 2]) / 2",
    answers: ["2", "17", "8", "6"],
    correct: "8",
    questionId: "333247"
  },
  {
    question: "¿Cuál es el resultado de operar 15 - ([6 + {4 - 2}] - (2 x 3))?",
    answers: ["11", "5", "8", "13"],
    correct: "13",
    questionId: "496293"
  },
  {
    question:"¿Cuál es el resultado de operar 20 - ([50 x 2] - 40)?",
    answers: ["-20", "-60", "-40", "0"],
    correct: "-40",
    questionId: "588909"
  },
  {
    question:"¿Cuál es el resultado de operar (100 / 2) + (50 x 2 + (40 - 20))?",
    answers: ["150", "170", "130", "190"],
    correct: "9050",
    questionId: "648452"
  },
  {
    question:"¿Cuál es el resultado de operar (10 + 10 + 10 + 10 + 10) / 2?",
    answers: ["2","10","50","25"],
    correct: "25",
    questionId: "786649"
  },
  {
    question:"¿Cuál es el resultado de operar [5 x 2 + 10 x 1] + (4 + 1)?",
    answers: ["28","25","20","14"],
    correct: "25",
    questionId: "839754"
  },
  {
    question:"¿Cuál es el resultado de operar (5 x 5 / [{5 x 6} - 5])?",
    answers: ["0","25","1","4"],
    correct: "1",
    questionId: "98390"
  },
  {
    question:"¿Cuál es el resultado de operar (20 + 1) / [(4 x 2) - 1]?",
    answers: ["2","1","4","3"],
    correct: "3",
    questionId: "1071006"
  },
  {
    question:"¿Cuál es el resultado de operar 22 + (22 / 11)?",
    answers: ["24","20","4","8"],
    correct: "24",
    questionId: "1174154"
  },
  {
    question:"¿Cuál es el resultado de operar (50 - 40) / 2?",
    answers: ["10","5","20","1"],
    correct: "5",
    questionId: "1226535"
  },
  {
    question:"¿Cuál es el resultado de operar (8 x 2) - (3 x 3)?",
    answers: ["16","5","10","7"],
    correct: "7",
    questionId: "1310938"
  },
  {
    question:"¿Cuál es el resultado de operar (8 / 4) x 5?",
    answers: ["12","20","10","15"],
    correct: "10",
    questionId: "1436873"
  },
  {
    question: "¿Cuál es el resultado de operar (5 + [16 - {3 x 3}]) x 3?",
    answers: ["5", "6", "36", "32"],
    correct: "36",
    questionId: "1515110"
  },
  {
    question: "¿Cuál es el resultado de operar (16 x 4) + (16 - [9 / 3])?",
    answers: ["56", "75", "53", "77"],
    correct: "77",
    questionId: "1642728"
  },
  {
    question: "¿Cuál es el resultado de operar (5 x 5) + (6 / 2) - 4?",
    answers: ["24", "22", "26", "18"],
    correct: "24",
    questionId: "1747256"
  }
]

export default (n = 5) =>
  Promise.resolve(qBank.sort(() => 0.5 - Math.random()).slice(0, n))