const qBank = [
  {
    question: "Resuelva la siguiente ecuación lineal: 2x + 10 = 20",
    answers: ["10", "5", "4", "20"],
    correct: "5",
    questionId: "099099"
  },
  {
    question: "Efectúe la siguiente operación: (4x² - 2xy + 5) - (x² + xy - 1)",
    answers: ["3x² - 3xy + 4", "5x² + 3xy + 4", "3x² - 3xy + 6", "2x² - 5xy + 3"],
    correct: "3x² - 3xy + 6",
    questionId: "183452"
  },
  {
    question: "Resuelva la siguiente ecuación cuadrática: x² - 5x + 6 = 0",
    answers: ["3 y 2", "1 y 2", "-3 y -4", "5 y 3"],
    correct: "3 y 2",
    questionId: "267908"
  },
  {
    question: "Resuelva la siguiente ecuación lineal: 5x - 18 = 8 + 3x",
    answers: ["2", "5", "-13", "13"],
    correct: "13",
    questionId: "333247"
  },
  {
    question: "Desarrolle el siguiente producto notable: (x + 3)²",
    answers: ["x ² + 2x + 8", "x² + 2x + 3", "x² + 6x + 9", "x² + 7x + 10"],
    correct: "x² + 6x + 9",
    questionId: "496293"
  },
  {
    question: "Efectúe la siguiente operación: (2x + 5) · (2x - 5)",
    answers: ["4x² − 35","4x² − 10","4x² − 25","4x² − 15"],
    correct: "4x² − 25",
    questionId: "588909"
  },
  {
    question: "Resuelva la siguiente ecuación lineal: 3x + 1 = x + 3",
    answers: ["7", "2", "5", "1"],
    correct: "1",
    questionId: "648452"
  },
  {
    question: "Resuelva la siguiente ecuación cuadrática: x² - 5x - 84 = 0",
    answers: ["12 y -7", "12 y 6", "20 y -5", "8 y 10"],
    correct: "12 y -7",
    questionId: "786649"
  },
  {
    question: "Desarrolle el siguiente producto notable: (x-y)²",
    answers: ["x²+2xy+y²", "x²-2xy+y²", "2x²+2xy+y²", "x²-2xy-y²"],
    correct: "x²-2xy+y²",
    questionId: "839754"
  },
  {
    question: "Factorice la siguiente expresión: x³ + x²",
    answers: ["x²(x-1)","x²(x+1)","x³(x+1)","x²(x+4)"],
    correct: "x²(x+1)",
    questionId: "98390"
  },
  {
    question: "Resuelva la siguiente ecuación cuadrática: x² + x - 6 = 0",
    answers: ["-2 y 3", "2 y 3", "-3 y -2", "-3 y 2"],
    correct: "-3 y 2",
    questionId: "1071006"
  },
  {
    question: "Factorice la siguiente expresión: 4x² − 16",
    answers: ["(2x + 4) · (2x - 4)", "(2x + 8) · (2x - 2)", "(2x + 1) · (2x - 16)", "(2x + 4) · (2x - 8)"],
    correct: "(2x + 4) · (2x - 4)",
    questionId: "1174154"
  },
  {
    question: "Efectué la siguiente operación: 2ab² - 5a²b - 3ab² + 4ab² + a²b",
    answers: ["6ab² + 6a²b", "3ab² + 6a²b", "3ab² + 3a²b", "6ab² + 3a²b"],
    correct: "3ab² + 3a²b",
    questionId: "1226535"
  },
  {
    question: "Desarrolle el siguiente producto notable: (x + 5)²",
    answers: ["x² + 5x+ 15", "x² + 10x+ 5", "x² + 5x+ 30", "x² + 10x+ 25"],
    correct: "x² + 10x+ 25",
    questionId: "1310938"
  },
  {
    question: "Resuelva la siguiente ecuación cuadrática: x² - 2x + 1 = 0",
    answers: ["1", "2", "-1", "-2"],
    correct: "1",
    questionId: "1436873"
  },
  {
    question: "Resuelva la siguiente ecuación cuadrática: x² - 9 = 0",
    answers: ["9", "-3", "3", "-9"],
    correct: "3",
    questionId: "1515110"
  },
  {
    question: "Efectúe la siguiente operación: (a + b) · (a - b)",
    answers: ["a² - b²", "a² + b²", "2a² - 2b²", "3a² + 3b²"],
    correct: "a² - b²",
    questionId: "1642728"
  },
  {
    question: "Factorice la siguiente expresión: 25x² − 1",
    answers: ["(5x + 1) · (x - 1)", "(5x + 2) · (5x - 1)", "(5x + 1) · (5x - 1)", "(x + 1) · (25x - 1)"],
    correct: "(5x + 1) · (5x - 1)",
    questionId: "1747256"
  }
]

export default (n = 5) =>
  Promise.resolve(qBank.sort(() => 0.5 - Math.random()).slice(0, n))
