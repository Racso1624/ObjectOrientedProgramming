/*

DescriptionAboutUs.jsx

Autores:
Pedro Arriola 20188 패드로 아리어라
Oscar López 20679 어스칼 로팻스
Marco Orozco 마르코 오롯스코
Santiago Taracena 20017 산띠아고 탈으세나
Yong Park 20117 박용범

Última modificación: 2020-10-07

*/

// Librerías utilizadas.
import React, {Component} from "react"

// Estilos utilizados.
import "./styles/style.css"

// Clase DescriptionAboutUs que retorna el componente DescriptionAboutUs.
class DescriptionAboutUs extends Component {
    render() {
        return (
            <section id = "desc">
                <div className = "container">
                <h1 className = "titulo-desc">SOMOS UVG-MAKERS</h1>
                    <div className = "row text-center medium-bottom-margin">
                        <h5>
                            Como estudiantes, nuestro objetivo es mejorar el rendimiento 
                            en matemáticas de los estudiantes de preprimaria, primaria y 
                            secundaria en Guatemala con el aporte de nuestra página web. 
                            Somos un grupo de estudiantes de Ingeniería en Ciencia de la 
                            Computación apasionados por las ciencias exactas, especialmente 
                            por las matemáticas. Por esta razón, nuestro equipo de desarrollo 
                            se encuentra muy motivado para cumplir con las expectativas de 
                            nuestros usuarios e incentivarlos a que mejoren sus habilidades 
                            matemáticas, y no sólo eso, sino también que puedan sentir la 
                            pasión por las matemáticas que nosotros sentimos, y de esta forma 
                            ponerla en práctica.
                        </h5>
                    </div>
                </div>
            </section>
        )
    }
}

export default DescriptionAboutUs