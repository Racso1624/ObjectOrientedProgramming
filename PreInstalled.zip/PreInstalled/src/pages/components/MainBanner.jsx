/*

MainBanner.jsx

Autores:
Pedro Arriola 20188 패드로 아리어라
Oscar López 20679 어스칼 로팻스
Marco Orozco 마르코 오롯스코
Santiago Taracena 20017 산띠아고 탈으세나
Yong Park 20117 박용범

Última modificación: 2020-10-07

*/

// Librerías utilizadas.
import React, {Component} from "react"

// Imágenes utilizadas.
import Test from "./images/landingpageimages/eap.png"
import Waves from "./images/waves.png"

// Estilos utilizados.
import "./styles/bannerstyle.css"

// Clase MainBanner que retorna el componente MainBanner.
class MainBanner extends Component {
    render() {
        return (
            <section id = "banner">
                <div className = "container">
                    <div className = "row">
                        <div className = "col-md-6">
                            <p className = "titulo-atractivo">TU ÚNICO OBJETIVO: ¡SACAR 100!</p>
                            <h5>
                                A-Plus es una plataforma web cuyo objetivo es hacer de las
                                matemáticas una materia más divertida y accesible para todos.
                                Somos un grupo de estudiantes apasionados por las matemáticas
                                que buscamos que los niños y jóvenes guatemaltecos aprendan
                                las verdaderas utilidades de esta rama de las ciencias exactas,
                                y a su vez, lo apasionantes que son.
                            </h5>
                            <h5>
                                Confía en nosotros para que puedas mejorar tus notas de matemáticas.
                                Esforzarte y estudiar mucho dará sus frutos, y será un placer que logres 
                                tener mejores notas gracias a nuestra plataforma.
                            </h5>
                        </div>
                        <div className = "col-md-6 text center">
                            <img src = {Test} className = "img-banner"></img>
                        </div>
                    </div>
                </div>
                <img src = {Waves} className = "efectobanner"/>
            </section>
        )
    }
}

export default MainBanner